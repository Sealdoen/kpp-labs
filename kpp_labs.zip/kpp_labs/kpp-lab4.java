import java.util.Scanner;

public class FormulaCalculator {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Перше завдання: виведення номера варіанту
        System.out.print("Введіть номер вашого варіанту: ");
        int variantNumber = scanner.nextInt();
        System.out.println("Ваш номер варіанту: " + variantNumber);

        // Друге завдання: обчислення значення за формулою N(2) = N(sum) - N(V)
        System.out.print("Введіть кількість завдань (N(sum)): ");
        int totalTasks = scanner.nextInt();
        int N2 = totalTasks - variantNumber;
        System.out.println("Значення N(2): " + N2);

        // Додаткове завдання: робота з рядком
        scanner.nextLine(); // Очищення буфера після введення числа
        System.out.print("Введіть рядок: ");
        String inputString = scanner.nextLine();

        // Знаходження порядку між першою і останньою крапками
        int firstDotIndex = inputString.indexOf('.');
        int lastDotIndex = inputString.lastIndexOf('.');

        if (firstDotIndex != -1 && lastDotIndex != -1 && firstDotIndex < lastDotIndex) {
            String substring = inputString.substring(firstDotIndex + 1, lastDotIndex);
            System.out.println("Порядок між першою і останньою крапками: " + substring);
        } else {
            System.out.println("У введеному рядку немає двох крапок або вони розташовані некоректно.");
        }

        scanner.close();
    }
}
