// Task 1: Using ArrayList to manage a database of students
import java.util.ArrayList;

class Student {
    private String name;
    private String surname;
    private int age;
    private int course;
    private double averageMark;

    public Student(String name, String surname, int age, int course, double averageMark) {
        this.name = name;
        this.surname = surname;
        this.age = age;
        this.course = course;
        this.averageMark = averageMark;
    }

    public String getName() {
        return name;
    }

    public String getSurname() {
        return surname;
    }

    public int getAge() {
        return age;
    }

    public int getCourse() {
        return course;
    }

    public double getAverageMark() {
        return averageMark;
    }

    @Override
    public String toString() {
        return "Student{" +
                "name='" + name + '\'' +
                ", surname='" + surname + '\'' +
                ", age=" + age +
                ", course=" + course +
                ", averageMark=" + averageMark +
                '}';
    }
}

public class Main {
    public static void main(String[] args) {
        // Task 1: ArrayList Implementation
        ArrayList<Student> studentDatabase = new ArrayList<>();

        // Adding students
        studentDatabase.add(new Student("John", "Doe", 20, 2, 4.5));
        studentDatabase.add(new Student("Jane", "Smith", 21, 3, 3.8));
        studentDatabase.add(new Student("Emily", "Davis", 19, 1, 4.2));

        // Display all students
        System.out.println("--- ArrayList Student Database ---");
        for (Student student : studentDatabase) {
            System.out.println(student);
        }

        // Task 2: LinkedList Implementation
        java.util.LinkedList<Student> studentLinkedList = new java.util.LinkedList<>(studentDatabase);

        // Adding a student to the beginning
        studentLinkedList.addFirst(new Student("Michael", "Brown", 22, 4, 3.9));

        // Removing the last student
        studentLinkedList.removeLast();

        // Display all students
        System.out.println("\n--- LinkedList Student Database ---");
        for (Student student : studentLinkedList) {
            System.out.println(student);
        }

        // Task 3: HashMap Implementation
        java.util.HashMap<String, Student> studentHashMap = new java.util.HashMap<>();

        // Adding students to the HashMap
        for (Student student : studentDatabase) {
            studentHashMap.put(student.getSurname(), student);
        }

        // Display all students in the HashMap
        System.out.println("\n--- HashMap Student Database ---");
        for (String surname : studentHashMap.keySet()) {
            System.out.println("Key: " + surname + ", Value: " + studentHashMap.get(surname));
        }

        // Accessing a student by surname
        String searchSurname = "Smith";
        System.out.println("\n--- Accessing Student by Surname ---");
        System.out.println("Student with surname '" + searchSurname + "': " + studentHashMap.get(searchSurname));
    }
}
