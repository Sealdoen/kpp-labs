// Base class: Organization
class Organization {
    private String name;
    private String location;

    // Constructor
    public Organization(String name, String location) {
        this.name = name;
        this.location = location;
    }

    // Getters and setters
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    // Display information
    public void displayInfo() {
        System.out.println("Organization Name: " + name);
        System.out.println("Location: " + location);
    }
}

// Subclass: InsuranceCompany
class InsuranceCompany extends Organization {
    private String insuranceType;

    // Constructor
    public InsuranceCompany(String name, String location, String insuranceType) {
        super(name, location);
        this.insuranceType = insuranceType;
    }

    public String getInsuranceType() {
        return insuranceType;
    }

    public void setInsuranceType(String insuranceType) {
        this.insuranceType = insuranceType;
    }

    @Override
    public void displayInfo() {
        super.displayInfo();
        System.out.println("Insurance Type: " + insuranceType);
    }
}

// Subclass: OilAndGasCompany
class OilAndGasCompany extends Organization {
    private int numberOfRigs;

    // Constructor
    public OilAndGasCompany(String name, String location, int numberOfRigs) {
        super(name, location);
        this.numberOfRigs = numberOfRigs;
    }

    public int getNumberOfRigs() {
        return numberOfRigs;
    }

    public void setNumberOfRigs(int numberOfRigs) {
        this.numberOfRigs = numberOfRigs;
    }

    @Override
    public void displayInfo() {
        super.displayInfo();
        System.out.println("Number of Rigs: " + numberOfRigs);
    }
}

// Subclass: Factory
class Factory extends Organization {
    private String productType;

    // Constructor
    public Factory(String name, String location, String productType) {
        super(name, location);
        this.productType = productType;
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    @Override
    public void displayInfo() {
        super.displayInfo();
        System.out.println("Product Type: " + productType);
    }
}

// Test application
public class Main {
    public static void main(String[] args) {
        // Create instances of each class
        InsuranceCompany insuranceCompany = new InsuranceCompany("SafeLife", "New York", "Health Insurance");
        OilAndGasCompany oilAndGasCompany = new OilAndGasCompany("PetroCorp", "Houston", 15);
        Factory factory = new Factory("TechMakers", "San Francisco", "Electronics");

        // Display information
        System.out.println("--- Insurance Company ---");
        insuranceCompany.displayInfo();

        System.out.println("\n--- Oil and Gas Company ---");
        oilAndGasCompany.displayInfo();

        System.out.println("\n--- Factory ---");
        factory.displayInfo();
    }
}
