import java.io.*;
import java.util.Scanner;

// Власний клас винятку
class CustomException extends Exception {
    public CustomException(String message) {
        super(message);
    }
}

public class FormulaCalculator {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        try {
            // Перше завдання: демонстрація власного винятку
            System.out.print("Введіть значення для перевірки (потрібно більше 10): ");
            int value = scanner.nextInt();
            if (value <= 10) {
                throw new CustomException("Значення повинно бути більше 10!");
            } else {
                System.out.println("Введене значення: " + value);
            }
        } catch (CustomException e) {
            System.err.println("Власний виняток: " + e.getMessage());
        }

        try {
            // Друге завдання: NullPointerException
            String nullString = null;
            System.out.println(nullString.length()); // Викликає NullPointerException
        } catch (NullPointerException e) {
            System.err.println("Виняток: NullPointerException (спроба доступу до null)");
        }

        try {
            // Друге завдання: IOException
            System.out.print("Введіть шлях до файлу: ");
            scanner.nextLine(); // Очищення буфера
            String filePath = scanner.nextLine();
            BufferedReader reader = new BufferedReader(new FileReader(filePath));
            System.out.println("Перший рядок файлу: " + reader.readLine());
            reader.close();
        } catch (IOException e) {
            System.err.println("Виняток: IOException (помилка вводу/виводу)");
        }

        try {
            // Друге завдання: створення ArithmeticException
            System.out.print("Введіть число для ділення на нуль: ");
            int number = scanner.nextInt();
            int result = number / 0; // Викликає ArithmeticException
            System.out.println("Результат: " + result);
        } catch (ArithmeticException e) {
            System.err.println("Виняток: ArithmeticException (ділення на нуль)");
        }

        scanner.close();
    }
}
