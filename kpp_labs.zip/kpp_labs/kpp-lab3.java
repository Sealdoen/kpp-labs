import java.util.Scanner;

public class FormulaCalculator {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Введення значення A
        System.out.print("Введіть значення A: ");
        double A = scanner.nextDouble();

        // Введення кількості елементів n
        System.out.print("Введіть кількість елементів n: ");
        int n = scanner.nextInt();

        // Ініціалізація масиву b та заповнення його значень
        double[] b = new double[n];
        System.out.println("Введіть значення масиву b (" + n + " елементів):");
        for (int i = 0; i < n; i++) {
            System.out.print("b[" + (i + 1) + "] = ");
            b[i] = scanner.nextDouble();
        }

        // Обчислення суми елементів масиву b
        double sumB = 0;
        for (int i = 0; i < n; i++) {
            sumB += b[i];
        }

        // Обчислення значення C за формулою
        double C = A - sumB;

        // Виведення результату
        System.out.println("Результат обчислення: C = " + C);

        scanner.close();
    }
}
